package ca.sheridancollege.dossanic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A2NickDApplicationTests {

	@Test
	void contextLoads() {
	}

}
