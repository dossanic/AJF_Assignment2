import { Feed } from './feed';

describe('Feed', () => {
  it('should create an instance', () => {
    expect(new Feed()).toBeTruthy();
  });
});
