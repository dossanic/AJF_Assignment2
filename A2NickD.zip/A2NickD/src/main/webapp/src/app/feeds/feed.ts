export class Feed {
	id?: number;
	author?: string;
	title?: string;
	details?: string;
	time?: string;
	date?: string;
}
